
from django.views import View
from django.shortcuts import render,redirect
from . import models
from .forms import UserForm, RegisterForm

# Create your views here.

def index(request):
    pass
    return render(request,'login/index.html')

def logout(request):
    pass
    return redirect('/index/')

#登录功能实现
def login(request):
    if request.session.get('is_login',None):
        #如果本来就是登陆，也没有登出的说法
        return redirect('/index/')
    if request.method=="POST":
        login_form = UserForm(request.POST)
        message = "请检查填写的内容！"

        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            #用户名字符合合法性验证
            #密码长度验证
            #其他的验证
            try:
                user=models.User.objects.get(name=username)
                if user.password==password:
                    request.session['is_login']=True
                    request.session['user_id']=user.id
                    request.session['user_name']=user.name
                    return redirect('/index/')
                else:
                    message="密码不正确！"
            except:
                message="用户不存在!"
        return render(request,'login/login.html',locals())

    login_form=UserForm()
    return render(request,'login/login.html',locals())

#用户退出功能实现
def logout(request):
    if not request.session.get('is_login',None):
        return redirect('/index/')
    request.session.flush()
    return redirect('/index/')



#注册功能实现
def register(request):
    if request.session.get('is_login', None):
        # 登录状态不允许注册。你可以修改这条原则！
        return redirect("/index/")
    if request.method == "POST":
        register_form = RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():  # 获取数据
            username = register_form.cleaned_data['username']
            password1 = register_form.cleaned_data['password1']
            password2 = register_form.cleaned_data['password2']
            email = register_form.cleaned_data['email']
            sex = register_form.cleaned_data['sex']
            if password1 != password2:  # 判断两次密码是否相同
                message = "两次输入的密码不同！"

                return render(request, 'login/register.html', locals())
            else:
                same_name_user = models.User.objects.filter(name=username)
                if same_name_user:  # 用户名唯一
                    message = '用户已经存在，请重新选择用户名！'
                    return render(request, 'login/register.html', locals())
                same_email_user = models.User.objects.filter(email=email)
                if same_email_user:  # 邮箱地址唯一
                    message = '该邮箱地址已被注册，请使用别的邮箱！'
                    return render(request, 'login/register.html', locals())

                # 当一切都OK的情况下，创建新用户

                new_user = models.User.objects.create()
                new_user.name = username
                new_user.password = password1
                new_user.email = email
                new_user.sex = sex
                new_user.save()
                request.session['user_name']=username
                return redirect('/login/')  # 自动跳转到登录页面
    register_form = RegisterForm()
    return render(request, 'login/register.html', locals())

# 2010年分析图的视图显示
class Ten(View):
    def get(self, request):
        pass
        return render(request, 'login/2010.html')


# 2011年分析图的视图显示
class eleven(View):
    def get(self, request):
        pass
        return render(request, 'login/2011.html')


# 2012年分析图的视图显示
class twelve(View):
    def get(self, request):
        pass
        return render(request, 'login/2012.html')


# 2013年分析图的视图显示
class thirteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2013.html')


# 2014年分析图的视图显示
class fourteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2014.html')


# 2015年分析图的视图显示
class fifteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2015.html')


# 2016年分析图的视图显示
class sixteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2016.html')


# 2017年分析图的视图显示
class seventeen(View):
    def get(self, request):
        pass
        return render(request, 'login/2017.html')


# 2018年分析图的视图显示
class eighteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2018.html')


# 2019年分析图的视图显示
class nineteen(View):
    def get(self, request):
        pass
        return render(request, 'login/2019.html')


# 2020年分析图的视图显示
class twenty(View):
    def get(self, request):
        pass
        return render(request, 'login/2020.html')
