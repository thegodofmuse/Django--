from django.urls import path
from django.contrib import admin
from .views import index, login, register, logout, Ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, \
    eighteen, nineteen, twenty

# 在子应用下创建urls.py文件，在里面注册视图的路由函数，连接前端和后台。
urlpatterns = [
    path('index/', index.as_view()),  # 主页
    path('login/', login.as_view()),  # 登录
    path('register/', register.as_view()),  # 注册
    path('logout/', logout.as_view()),  # 登出
    path('index/2010.html/', Ten.as_view()),  # 2010年分析图
    path('index/2011.html/', eleven.as_view()),  # 2011年分析图
    path('index/2012.html/', twelve.as_view()),  # 2012年分析图
    path('index/2013.html/', thirteen.as_view()),  # 2013年分析图
    path('index/2014.html/', fourteen.as_view()),  # 2014年分析图
    path('index/2015.html/', fifteen.as_view()),  # 2015年分析图
    path('index/2016.html/', sixteen.as_view()),  # 2016年分析图
    path('index/2017.html/', seventeen.as_view()),  # 2017年分析图
    path('index/2018.html/', eighteen.as_view()),  # 2018年分析图
    path('index/2019.html/', nineteen.as_view()),  # 2019年分析图
    path('index/2020.html/', twenty.as_view()),  # 2020年分析图

]
